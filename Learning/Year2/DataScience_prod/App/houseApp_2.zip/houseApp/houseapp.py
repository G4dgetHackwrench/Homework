# export FLASK_APP=houseapp.py

from app import app
